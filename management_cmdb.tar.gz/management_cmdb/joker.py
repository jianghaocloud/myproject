from flask import Blueprint
from flask import request
from flask import send_from_directory
from werkzeug.utils import secure_filename
import time
import os
import json
import simplejson

joker = Blueprint('joker', __name__)

@joker.route('/index')
def index():
    return "Blueprint joker"

@joker.route('/ajaxget')
def ajaxget():
    server_name = request.args.get('server_name')
    server_ip = request.args.get('server_ip')
    return server_ip + server_name

@joker.route('/ajaxpost', methods=['get', 'post'])
def ajaxpost():
    info = request.get_data()
    info = simplejson.loads(info)
    return info['username']


@joker.route('/ajaxtest')
def ajaxtest():
    return "joker ajax test"

@joker.route('/get')
def get():
    print(request.args)
    server_name = request.args.get("server_name")
    server_ip = request.args.get("server_ip")
    return 'server_name is {}, server_ip  is {}'.format(server_name, server_ip)

@joker.route('/post', methods=['get', 'post'])
def post():
    print(request.form)
    username = request.form.get("username")
    password = request.form.get("password")
    return 'username is {}, server_ip  is {}'.format(username, password)

@joker.route('/upload', methods=['get', 'post'])
def upload():
    servers = request.files.get('servers')
    filename = secure_filename(servers.filename)
    # print(servers.filename)
    # print(filename)
    ramname = int(time.time() * 1000)
    print(ramname)
    servers.save('e:\{}'.format(ramname))
    return "Upload success"

@joker.route('/download', methods=['get', 'post'])
def download():
    print(os.path.realpath(__file__))
    print(os.path.dirname(os.path.realpath(__file__)))
    curent_dir = os.path.dirname(os.path.realpath(__file__))
    return send_from_directory(curent_dir+'/static',"add_host2group.xlsx", as_attachment=True)
