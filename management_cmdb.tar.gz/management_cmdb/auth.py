from flask import Blueprint
from flask import request
from flask import redirect
from flask import make_response
from flask import session
import tool_db, tool_pass

auth = Blueprint('auth', __name__)


# @auth.route('/login', methods = ['get', 'post'])
# def login():
#     username = request.form.get('username')
#     password = request.form.get('password')
#     if username == "joker" and password == "joker":
#         response = make_response(redirect('/views/servers'))
#         response.set_cookie('username', username, max_age=86400)
#         return response
#         #return redirect("/views/servers")
#     else:
#         return redirect("/static/login.html")


# @auth.route('/logout')
# def logout():
#     response = make_response(redirect('/static/login.html'))
#     response.delete_cookie('username')
#     return response

@auth.route('/login', methods=['get', 'post'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    # if username == "joker" and password == "joker":
    password = tool_pass.md5encrypt(password)
    sql = "select * from user where username = %s and password = %s"

    result = tool_db.selectByParameters(sql, (username, password))
    if result:
        session['username'] = username
        # return response
        return redirect("/views/servers")
    else:
        return redirect("/static/login.html")


@auth.route('/logout')
def logout():
    if 'username' in session:
        del session['username']
    return redirect('/static/login.html')
